# Jay & Co Jewellers — Production Website Bundle

This is the current static website. No build step or package install is required.

## Deploy

Upload the ZIP contents (not the ZIP itself) to the web root of a static host, or extract it and deploy the folder. The homepage is `index.html`.

The bundle includes all site pages, shared CSS and JavaScript, local images and fonts, product photography, favicon/app icons, SEO files, security headers, and the Vercel configuration.

For a local check, run `python3 -m http.server 8080` from the extracted folder, then open `http://localhost:8080`.

The enquiry form currently provides client-side validation only; connect a mail/CRM endpoint before relying on it to receive submissions.
